num=int(input("Enter a number:"))
if(num%3)==0:
   print("Enter a number is even")
else:
   print("Enter a number is odd")   