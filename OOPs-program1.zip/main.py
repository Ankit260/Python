class Student:
  pass

ankit=Student()
anurag=Student()

ankit.name="ankit"
anurag.salary=4999
ankit.subjects=["hindi","english","maths"]

print(anurag.salary)
print(ankit.subjects)





